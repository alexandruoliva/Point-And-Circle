package movable.exceptions;

public class HowMuchExc extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1652364956890793498L;

	public HowMuchExc(String msg) {
		super(msg);
	}
}
