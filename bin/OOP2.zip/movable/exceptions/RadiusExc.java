package movable.exceptions;

public class RadiusExc extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5350210274417525169L;

	public RadiusExc(String msg) {
		super(msg);
	}
}
