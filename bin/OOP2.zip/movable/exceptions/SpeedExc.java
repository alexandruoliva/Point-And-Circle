package movable.exceptions;

public class SpeedExc extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7542713116332869787L;

	public SpeedExc(String msg) {
		super(msg);
	}
}
