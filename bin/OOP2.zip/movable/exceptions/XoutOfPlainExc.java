package movable.exceptions;

public class XoutOfPlainExc extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4199806777579133712L;

	public XoutOfPlainExc(String msg) {
		super(msg);

	}
}
