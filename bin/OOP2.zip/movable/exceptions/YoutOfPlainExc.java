package movable.exceptions;

public class YoutOfPlainExc extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3945740472966992359L;

	public YoutOfPlainExc(String msg) {
		super(msg);
	}
}
